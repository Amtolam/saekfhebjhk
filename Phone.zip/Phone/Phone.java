public class Phone{
    public Phone(){
        //JAVAAAAA
    }
    
}