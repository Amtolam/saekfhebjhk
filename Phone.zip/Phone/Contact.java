
public class Contact{
    final String name;
    final String num;
    public Contact(String name, String num){
        this.name = name;
        this.num = num;
    }
}
