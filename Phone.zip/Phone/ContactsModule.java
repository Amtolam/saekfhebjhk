
class DuplicateException extends Exception {
    
}


public class ContactsModule{
    private Contact[] contacts = new Contact[10];
    
    public void newContact(String name, String num){
        int freeIndex = -1;
        
        for (int i=0; i<contacts.length; i++) {
            if (contacts[i].num == num) {
                throw new RuntimeException(); //fix later
            }
            if (contacts[i] == null && freeIndex < 0) {
                freeIndex = i;
            } 
        }
        
        if (! (freeIndex > 0)) {throw new RuntimeException();} //fix later
        
        contacts[freeIndex] = new Contact(name, num);
    }
}